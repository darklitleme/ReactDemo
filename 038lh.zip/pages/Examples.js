import React from "react";
import Covid from "./miniApps/Covid";

export default function Examples() {
  return (
    <div className="overlay">
      <Covid />
    </div>
  );
}
